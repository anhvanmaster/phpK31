<?php

    namespace Librarys\Minify\Exceptions;

    if (defined('LOADED') == false)
        exit;

    /**
     * @author Matthias Mullie <minify@mullie.eu>
     */
    class IOException extends BasicException
    {
    }

?>