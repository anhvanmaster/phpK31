<?php

    namespace Librarys\Minify;
    /**
     * @deprecated Use Exceptions\BasicException instead
     *
     * @author Matthias Mullie <minify@mullie.eu>
     */

    if (defined('LOADED') == false)
        exit;

    abstract class Exception extends \Exception
    {

    }

?>