<?php

    if (defined('LOADED') == false)
        exit;

    return [
        'name' => 'Manager',
        'author' => 'Izero.Cs',
        'version' => '3.5.0',
        'is_beta' => true,
        'email' => 'Izero.Cs@gmail.com',
        'fb_link' => 'https://facebook.com/Izero.Cs',
        'fb_title' => 'fb.com/Izero.Cs',
        'git_link' => 'https://github.com/IzeroCs/Manager',
        'git_title' => 'IzeroCs/Manager',
        'phone' => '+841685929323',
        'create_at' => 1434468025,
        'upgrade_at' => 1496595751,
        'check_at' => 1496600922,
        'build_at' => 1396595420,
    ];

?>