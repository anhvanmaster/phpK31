<?php

    if (defined('LOADED') == false)
        exit;

    return [
        'title_page' => 'Kiểm tra ứng dụng'
    ];

?>